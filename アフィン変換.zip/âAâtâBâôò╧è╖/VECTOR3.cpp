#include "VECTOR3.h"



VECTOR3::VECTOR3()
{
}


VECTOR3::~VECTOR3()
{
}

VECTOR3 VECTOR3::operator+=(const VECTOR3 & f)
{
	x += f.x;
	y += f.y;
	return *this;
}

VECTOR3 VECTOR3::operator-=(const VECTOR3 & f)
{
	x -= f.x;
	y -= f.y;
	return *this;
}

VECTOR3 VECTOR3::operator*=(const float & k)
{
	x *= k;
	y *= k;
	z *= k;
	return *this;
}

VECTOR3 operator/(const VECTOR3 & p, const float & f)
{
	VECTOR3 tmp;
	tmp.x = p.x / f;
	tmp.y = p.y / f;
	return tmp;
}

VECTOR3 operator-(const VECTOR3 & p, const VECTOR3& v)
{
	VECTOR3 tmp;
	tmp.x = p.x - v.x;
	tmp.y = p.y - v.y;
	tmp.z = p.z - v.z;
	return tmp;
}

VECTOR3 operator+(const VECTOR3 & p, const VECTOR3 & v)
{
	VECTOR3 tmp;
	tmp.x = p.x + v.x;
	tmp.y = p.y + v.y;
	return tmp;
}
