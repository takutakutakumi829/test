#include "AffineTransformation.h"

constexpr float PI = 3.141592653589793f;

namespace
{
	float Rad(float theta)
	{
		return 	float(theta / 180 * PI);
	}

	float Deg(float phi)
	{
		return float(phi / PI * 180);
	}

	Matrix Mat(VECTOR3 pos)
	{
		return Matrix(VECTOR3(1, 0, pos.x), VECTOR3(0, 1, pos.y), VECTOR3(0, 0, pos.z));
	}
}

AffineTransformation::AffineTransformation(): _mat(Matrix(VECTOR3(0,0,0), VECTOR3(0,0,0), VECTOR3(0,0,0)))
{
}

AffineTransformation::AffineTransformation(VECTOR3 p): _mat(Matrix(VECTOR3(0, 0, 0), VECTOR3(0, 0, 0), VECTOR3(0, 0, 0))), _pos(p)
{

}


AffineTransformation::~AffineTransformation()
{
}

void AffineTransformation::Init()
{
	_mat = Matrix(VECTOR3(1, 0, 0), VECTOR3(0, 1, 0), VECTOR3(0, 0, 1));
}

void AffineTransformation::Translation(float x, float y)
{
	_mat = Matrix(VECTOR3(1, 0, x), VECTOR3(0, 1, y), VECTOR3(0, 0, 1));
}

void AffineTransformation::TranslationAdd(float x, float y)
{
	Translation(_pos.x, _pos.y);
	_mat = Matrix(VECTOR3(1, 0, x), VECTOR3(0, 1, y), VECTOR3(0, 0, 1)) * _mat;

	_pos = _mat.GetTransAddVec(_mat);
}

void AffineTransformation::SetToRotation(float angle)
{
	auto theta = Rad(angle);
	_mat = Matrix(VECTOR3(cos(theta), -sin(theta), 0), VECTOR3(sin(theta), cos(theta), 0), VECTOR3(0, 0, 1));
}

void AffineTransformation::AddToRotation(float angle, float x, float y)
{
	auto theta = Rad(angle);
	Translation(_pos.x, _pos.y);
	_mat = Matrix(VECTOR3(cos(theta), -sin(theta), x), VECTOR3(sin(theta), cos(theta), y), VECTOR3(0, 0, 1)) * _mat;
	_pos = _mat.GetTransAddVec(_mat);

}

void AffineTransformation::Rotation(float angle)
{
	auto theta = Rad(angle);
	Translation(_pos.x, _pos.y);
	_mat = Matrix(VECTOR3(cos(theta), -sin(theta), 0), VECTOR3(sin(theta), cos(theta), 0), VECTOR3(0, 0, 1)) * _mat;
	_pos = _mat.GetTransAddVec(_mat);
}

const VECTOR3& AffineTransformation::Rotation(VECTOR3 pos , float angle)
{
	auto theta = Rad(angle);
	auto value = Matrix(VECTOR3(cos(theta), -sin(theta), 0), VECTOR3(sin(theta), cos(theta), 0), VECTOR3(0, 0, 1)) * Mat(pos);
	return _mat.GetTransAddVec(value);
}

void AffineTransformation::Skew(float x, float y)
{
	Translation(_pos.x, _pos.y);
	_mat = Matrix(VECTOR3(1, x, 0), VECTOR3(y, 1, 0), VECTOR3(0, 0, 1)) * _mat;
	_pos = _mat.GetTransAddVec(_mat);
}


const VECTOR3& AffineTransformation::Skew(VECTOR3 pos, float x, float y)
{
	auto value = Matrix(VECTOR3(1, x, 0), VECTOR3(y, 1, 0), VECTOR3(0, 0, 1)) * Mat(pos);
	return _mat.GetTransAddVec(value);
}

const VECTOR3& AffineTransformation::GetVector()
{
	return _pos;
}
