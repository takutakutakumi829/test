#pragma once
#include "VECTOR3.h"
#include <vector>


struct Matrix
{
	using vecFloat = std::vector<float>;
	vecFloat v1;
	std::vector<vecFloat> vec;

	Matrix() 
	{

	};
	Matrix(VECTOR3 n1, VECTOR3 n2, VECTOR3 n3)
	{
		v1.emplace_back(n1.x);
		v1.emplace_back(n1.y);
		v1.emplace_back(n1.z);
		vec.emplace_back(v1);
		v1.clear();
		v1.emplace_back(n2.x);
		v1.emplace_back(n2.y);
		v1.emplace_back(n2.z);
		vec.emplace_back(v1);
		v1.clear();
		v1.emplace_back(n3.x);
		v1.emplace_back(n3.y);
		v1.emplace_back(n3.z);
		vec.emplace_back(v1);

	};

	Matrix& operator*=(float k)
	{
		for (auto& v : v1)
		{
			v *= k;
		}
		return *this;// IN:scalar  OUT:this
	}

	//���W�̂ݎ擾
	VECTOR3 GetTransAddVec(const Matrix& a)
	{
		VECTOR3 w(0, 0, 0);

		//�c
		for (int i = 0; i< a.vec.size(); i++) {

			w.vec[i] = 0;
			//��
			for (int j = 0; j< a.vec[i].size(); j++)
			{
				//auto vVec = v.vec[j];
				auto av = a.vec[i][j];
				w.vec[i] += /*vVec * */av;
			}
			w.vec[i] -= 1;
		}
		
		w.x = w.vec[0];
		w.y = w.vec[1];
		w.z = w.vec[2];
		return w;
	}
};

//#define Trans(X,Y) Matrix(VECTOR3(1,0,X),VECTOR3(0,1,Y),VECTOR3(0,0,1))


class AffineTransformation
{
public:
	AffineTransformation();
	AffineTransformation(VECTOR3 p);

	~AffineTransformation();
	void Init();
	void TranslationAdd(float x, float y);//���s�ړ�

	void SetToRotation(float angle);//��]�ϊ��p�̐ݒ�
	void AddToRotation(float angle, float x, float y);//��]�A�ړ�

	void Rotation(float angle);
	const VECTOR3& Rotation(VECTOR3 pos, float angle);

	void Skew(float x, float y);//�X�L���[�ϊ�
	const VECTOR3 & Skew(VECTOR3 pos, float x, float y);

	const VECTOR3& GetVector();//���W�̎擾


private:
	void Translation(float x, float y);//���s�ړ��ϊ�

	Matrix _mat;
	VECTOR3 _pos;
};

inline Matrix operator*(const Matrix& a, const Matrix& b) {//IN:Matrix3D Matrix3D OUT:Matrix3D
	Matrix c(VECTOR3(0,0,0),VECTOR3(0,0,0),VECTOR3(0,0,0));//C=O
	for (int i = 0; i< a.vec.size(); i++) 
	{
		for (int j = 0; j< a.vec[i].size(); j++) 
		{
			for (int k = 0; k < a.vec.size(); k++)
			{
				auto av = a.vec[i][k];
				auto bv = b.vec[k][j];
				auto value = av * bv;
				c.vec[i][j] += value;
			}
		}
	}
	return c;
}

inline VECTOR3 operator*(const Matrix& a, const VECTOR3& v) {//IN:Vector3D Matrix3D OUT:Vector3D 
	VECTOR3 w(0,0,0);

	//�c
	for (int i = 0; i< a.vec.size(); i++) {

		w.vec[i] = 0;
		//��
		for (int j = 0; j< a.vec[i].size(); j++)
		{
			auto vVec = v.vec[j];
			auto av = a.vec[i][j];
			w.vec[i] += vVec * av;
		}
	}
	return w;
}
